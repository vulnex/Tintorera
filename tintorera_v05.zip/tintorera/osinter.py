# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS
#
# Tintorera OSINT
#
# name: osinter.py
# init date: 07/22/17
# last date: 07/22/17
# author: Simon Roses Femerling
# desc: Search for OSINT data in source code
#
# www.vulnex.com

import getopt
import sys
import re
from commonregex import CommonRegex

from tintorera_lib import tintolib

########################################################################
# Global Variable
########################################################################

data_dict =  {}

do_source_code_file_only = False

do_verbose = False

source_code_file_list = []

osint_list = []

output_dir = ""

dd=[]
#dd["phones"] = []
#dd["phones_with_exts"] = []
#dd["links"] = []
#dd["emails"] = []
#dd["ips"] = []
#dd["ipv6s"] = []
#dd["credit_cards"] = []
#dd["btc_addresses"] = []
#dd["street_addresses"] = []
#dd["twitter"] = []

########################################################################
# Funcrions
########################################################################

#
#
#
def Usage():
	print "Tintorera OSINT"
	print "Usage: osint.py -c tinto.json"
	print ""
	print "-h: This help"
	print "-v: Be verbose"	
	print "-f: Single file"
	print "-p: Path to folder"
	sys.exit(2)

#
#
#
def RunOSINTDictsOnFile(scanfile):

	sp = open(scanfile)
	text = "".join(sp.readlines())
	parsed_data = CommonRegex(text)

	ds = {}
	ds["file"] = scanfile
	ds["phones"] = []
	ds["links"] = []
	ds["emails"] = []
	ds["ips"] = []
	ds["ipv6s"] = []
	ds["credit_cards"] = []	
	ds["btc_addresses"] = []
	ds["street_addresses"] = []
	ds["twitter"] = []
	
	if parsed_data.phones:
		pho = []
		for p in parsed_data.phones:
			if not p in pho:
				ds["phones"].append(p)
				pho.append(p)
	if parsed_data.links:
		lin=[]
		for l in parsed_data.links:
			if not l in lin:
				ds["links"].append(l)
				lin.append(l)

	if parsed_data.emails:
		ema = []
		for e in parsed_data.emails:
			if not e in ema:
				ds["emails"].append(e)
				ema.append(e)

	if parsed_data.ips:
		ip4 = []
		for i in parsed_data.ips:
			if not i in ip4:
				ds["ips"].append(i)
				ip4.append(i)

	if parsed_data.ipv6s:
		ip6 = []
		for ii in parsed_data.ipv6s:
			if not ii in ip6:
				ds["ipv6s"].append(ii)
				ip6.append(ii)

	if parsed_data.credit_cards:
		cc = []
		for c in parsed_data.credit_cards:
			if not c in cc:
				ds["credit_cards"].append(c)
				cc.append(c)

	if parsed_data.btc_addresses:
		btc = []
		for b in parsed_data.btc_addresses:
			if not b in btc:
				ds["btc_addresses"].append(b)
				btc.append(b)

	if parsed_data.street_addresses:
		sa = []
		for s in parsed_data.street_addresses:
			if not s in sa:
				ds["street_addresses"].append(s)
				sa.append(s)

	ta = re.findall("^@[A-Za-z0-9_]{1,15}$",text)
	if ta:
		tw = []
		for t in ta:
			if not t in tw:
				dd["twitter"].append(t)
				tw.append(t)

	dd.append(ds)	
	
	"""
	global dd
	if parsed_data.phones:
		dd["phones"].append(parsed_data.phones)
	#if parsed_data.phones_with_exts:
	#	dd["phones_with_exts"].append(parsed_data.phones_with_exts)
	if parsed_data.links:
		dd["links"].append(parsed_data.links)
	if parsed_data.emails:
		dd["emails"].append(parsed_data.emails)
	if parsed_data.ips:
		dd["ips"].append(parsed_data.ips)
	if parsed_data.ipv6s:
		dd["ipv6s"].append(parsed_data.ipv6s)
	if parsed_data.credit_cards:
		dd["credit_cards"].append(parsed_data.credit_cards)
	if parsed_data.btc_addresses:
		dd["btc_addresses"].append(parsed_data.btc_addresses)
	if parsed_data.street_addresses:
		dd["street_addresses"].append(parsed_data.street_addresses)

	ta = re.findall("^@[A-Za-z0-9_]{1,15}$",text)
	if ta:
		dd["twitter"] = ta

	"""
#
#
#
def RunOSINT(data):
	if data["file"] != "":
		RunOSINTDictsOnFile(data["file"])
	else:
		tintolib.scan_dir(data["folder"])
		global scan_files
		scan_files = tintolib.return_scan_files()
		for f in scan_files:
			RunOSINTDictsOnFile(f)

	global dd
	datax = {}
	datax["osint"] = dd
	global output_dir
        try:
        	tintolib.SaveFileJson(output_dir + "/" + tintolib.output_dir + "/" + "osinter.json",datax)
        except:
                tintolib.SaveFileJson(output_dir + "/" + "osinter.json",datax)

#
#
#
def doosint(data={}):
	if not data: Usage()

	do_config = tintolib.Read_Config_File(data["config"])

	if do_config:
		global output_dir
		output_dir = do_config["default"]["output_dir"]

		RunOSINT(data)
	else:
		Usage()

########################################################################
# Main
########################################################################
if __name__ == "__main__":

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hvc:f:p:")
	except:
		Usage()

	data = {}
	data["config"] = ""
	data["verbose"] = tintolib.NO
	data["folder"] = ""
	data["file"] = ""

	for o,a in opts:
		if o == "-h":
			Usage()
		elif o == "-c":
			data["config"] = a
		elif o == "-f":
			data["file"] = a
		elif o == "-p":
			data["folder"] = a
		elif o == "-v":
			do_verbose = True
		else:
			Usage()

	if data["config"] == "": Usage()

	if data["folder"] == "" and data["file"] == "":
		Usage()

	if data["folder"] != "" and data["file"] != "":
		Usage()

	doosint(data)

# VULNEX EOF
