# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS 
# 
# Tintorera Analyzer
# 
# name: analyzer.py
# init date: 08/10/13
# last date: 07/22/17
# author: Simon Roses Femerling
# desc: Perform an analysis of a given source code
#
# www.vulnex.com

#import ConfigParser
import gcc
from gccutils import cfg_to_dot, callgraph_to_dot, get_src_for_loc

from tintorera_lib import tintolib
from tintorera_lib import tintometrics

#import hashlib

########################################################################
# Global Variables
########################################################################

filesdata_list = []
filesdata_bb_list = []
filesmeta_list = []
data_dict = {}	

source_dir=""

#sha256 = hashlib.sha256()

########################################################################
# Helpers Functions
########################################################################

#
#
# RIpped and modify from gcc-python-plugin gccutils
"""
def internal_invoke_dot(dot, name='test'):
    	from subprocess import Popen, PIPE
        fmt = 'png'
    	filename = '%s.%s' % (name, fmt)
    	p = Popen(['dot', '-T%s' % fmt, '-o', filename],
        stdin=PIPE)
    	p.communicate(dot.encode('ascii'))
"""

#	
# Perform Code Complexity metric - Cyclomatic Complexity
#
def DoCC(fun):
	CC=1
        l = len(fun.cfg.basic_blocks)
        for i in range(0,l):
        	bx = fun.cfg.basic_blocks[i]
                for i,stmt in enumerate(bx.gimple):
                	if isinstance(stmt, gcc.GimpleCond) or isinstance(stmt, gcc.GimpleSwitch):
				CC+=1
        return CC

#
#
#
def DectectInlineASM(fun):
	l = len(fun.cfg.basic_blocks)
        for i in range(0,l):
        	bx = fun.cfg.basic_blocks[i]
                for stmt in bx.gimple:
                	if isinstance(stmt, gcc.GimpleAsm):
				return str(stmt)
	return ""

#
#
#
def CountGimples(fun):
	d = {}
	d['gimpleasm'] = 0
	d['gimpleassign'] = 0
	d['gimplecall'] = 0
	d['gimplecond'] = 0
	d['gimplelabel'] = 0
	d['gimplenop'] = 0
	d['gimplephi'] = 0
	d['gimplereturn'] = 0
	d['gimpleswitch'] = 0
        l = len(fun.cfg.basic_blocks)
        for i in range(0,l):
        	bx = fun.cfg.basic_blocks[i]
                for stmt in bx.gimple:
               		if isinstance(stmt, gcc.GimpleAsm):
				d['gimpleasm'] += 1 	
                        if isinstance(stmt, gcc.GimpleAssign):
				d['gimpleassign'] += 1 	
                        if isinstance(stmt, gcc.GimpleCall):
				d['gimplecall'] += 1 	
                        if isinstance(stmt, gcc.GimpleCond):
				d['gimplecond'] += 1 	
                        if isinstance(stmt, gcc.GimpleLabel):
				d['gimplelabel'] += 1 	
                        if isinstance(stmt, gcc.GimpleNop):
				d['gimplenop'] += 1 	
                        if isinstance(stmt, gcc.GimplePhi):
				d['gimplephi'] += 1 	
                        if isinstance(stmt, gcc.GimpleReturn):
				d['gimplereturn'] += 1 	
                        if isinstance(stmt, gcc.GimpleSwitch):
				d['gimpleswitch'] += 1 	
	return d			

def _doLOC(lines):

	c_lines = 0
	c_comments = 0
	c_blanks = 0
	c_code = 0
	strblock = None
        endblock = None
        inblock = False
        endcode = False
	lang = "C"
	l_comments = []
	c_block = 0	
	c_line_len = 0

	for line in lines:
        	#sha256.update(line.encode())
                c_lines += 1
                line = line.strip()
                identified = False

                if line == "":
                	c_blanks += 1
                    	continue

                if endcode:
			d={"comment":line,"line":c_lines}
			l_comments.append(d)
                    	c_comments += 1
                	continue

                if not inblock:
                	for token in tintolib.langs[lang]["bcomm"]:
                        	strblock = token
                        	endblock = tintolib.langs[lang]["bcomm"][token]

                        	while token in line:
                            		# If a block has started then check for an exit
                            		if endblock in line:
						d={"comment":line,"line":c_lines}
						l_comments.append(d)
                                		line = line.replace(line[line.find(strblock):line.find(endblock) + len(endblock)], "", 1)
                           		else:
						d={"comment":line,"line":c_lines,"block_id":c_block}
						l_comments.append(d)
                                		line = line.replace(line[line.find(strblock):], "", 1)
                                		inblock = True      # left open
                else:
                	# Continue until the block ends... when left open
                    	if endblock in line:
				d={"comment":line,"line":c_lines,"block_id":c_block}
				l_comments.append(d)
				c_block+=1
                        	inblock = False     # End the block
                        	line = line.replace(line[:line.find(endblock) + len(endblock)],"").strip()
                    	else:
				d={"comment":line,"line":c_lines,"block_id":c_block}
				l_comments.append(d)
                        	line = ""

                # From the block but no hidden code made it out the back....
                if line is "":
                	#logging.info(" bloc  " + str(filename.lines) + line)
			c_comments += 1
                    	continue

                # Check line comment designators
                for token in tintolib.langs[lang]["comment"]:
                	if line.startswith(token):
                       		d={"comment":line,"line":c_lines}
				l_comments.append(d)
				#logging.info(" line  " + str(filename.lines) + line)
                        	c_comments += 1
                        	identified = True
                        	break

                if identified:
			#l_comments.append(line)
                	continue

                # If not a blank or comment it must be code
                #logging.info(" code  " + str(filename.lines) + line)
                c_code += 1

                # Check for the ending of code statements
                for end in tintolib.langs[lang]["endcode"]:
                	if line == end:
                        	endcode = True

        # Store the hash of this file for comparison to others
        #logging.info("Total  "
        #        + " " + str(filename.blanks)
        #        + " " + str(filename.comments)
        #        + " " + str(filename.code))

        #sign = sha256.digest()
	sign = ""

	return (c_lines, c_comments, c_blanks, c_code, sign, l_comments)

	"""
	d = {}
	d["comments"] = []
	count = 0
	comment = 0
	blank = 0
	incomment = False

	for line in lines:
		line = line.strip()
		if incomment:
			d["comments"].append(line)
			end = line.find('*/')
			if end < 0:
				comment += 1
				continue
			else:
				incomment = False
				line = line[end+2:]
		if len(line)==0:
			blank += 1
			continue
		if line.startswith('//'):
			d["comments"].append(line)
			comment += 1
			continue
		if line.startswith('**'):
			d["comments"].append(line)
			comment += 1
			continue
		ind = line.find('/*')
		if ind >= 0:
			comment += 1
			incomment = True
			ind2 = line[ind+2:].find('*/')
			d["comments"].append(line)
			if ind2 >= 0:
				incomment = False
			if ind > 0 or ind2 < len(line)-2:						
				count += 1
			continue
		count += 1

	return (d,count,comment,blank)
	"""
#
#
# Ripped and modified from http://code.activestate.com/recipes/577546-linecountpy/
def GetLOC(fun): # NOT working
	start_line = fun.decl.location.line
        end_line = fun.end.line + 1
	srcfile = fun.start.file

	#d = {}
	#d['func_loc'] = 0
	#d['func_ploc'] = 0
	#d['func_blank'] = 0
	#d['func_code'] = []
	code = []
	code_line_len = []

	import linecache
        for linenum in range(start_line, end_line):
            #code.append(linecache.getline(srcfile, linenum))
            lin = linecache.getline(srcfile, linenum)
	    code_line_len.append({"line":linenum,"len":len(lin)})
            code.append(lin)

	# skip first emtpy line before func decl
	#if code[0] == '\n' : code = code[1:]

	(c_lines, c_comments, c_blanks, c_code, sign, l_comments) = _doLOC(code)

	d = {}
	d['func_loc'] = c_code
	d['func_ploc'] = c_lines
	d['func_comments_len'] = c_comments
	d['func_blank'] = c_blanks
	d['func_code'] = code
	d["func_start_line"] = start_line
	d["func_end_line"] = end_line
	d["func_sha256"] = sign
	d["func_comments"] = l_comments
	d["func_lines_len"] = code_line_len
	return d
			
#
#
#
def DoAPI(fun):
	li = []
	#for d in data_dict['api_config']:
	#if d[0] == "api":
	#for a in data_dict['api_data']['apis']:
	#print data_dict["api"]
	for a in data_dict['api_data']["apis"]:
		#print a
		#if a['cat'] in d[1]: 
		if a['cat'] in data_dict["api"]: 
			l = len(fun.cfg.basic_blocks)
                	for i in range(0,l):
                		bx = fun.cfg.basic_blocks[i]
                       		#for i,stmt in enumerate(bx.gimple):
                       		for stmt in bx.gimple:
                        		if isinstance(stmt, gcc.GimpleCall):
						if str(stmt.fn).lower() in list(a['api_names:']):
							di =  {}
							di['api'] = str(stmt.fn)
							di['loc'] = str(stmt.loc)
							di['cat'] = a['cat']
							di['color'] = a['default_color']
							li.append(di)
	return li

#
#
#
def DoGimpleGraph(fun,name):
	try:
		dot = cfg_to_dot(fun.cfg, fun.decl.name)
		#internal_invoke_dot(dot,name)		
		tintolib.tinan_invoke_dot(dot,name)		
	except: pass

#
#
#
def DoBBComplexityGraph(fun,name):
	dot = tintolib.tinan_cfg_to_dot(fun.cfg, fun.decl.name)
	#internal_invoke_dot(dot,name)		
	tintolib.tinan_invoke_dot(dot,name)		

#
#
#
def DoFuncDecl(fun):
	d = {}
	d['func_name'] = fun.decl.name
	d['func_args'] =  [str(t) for t in fun.decl.type.argument_types] 
	d['func_return'] = str(fun.decl.type.type)
	#d['loc'] = str(fun.decl.location)
	return d

#
#
#
def GetMetaInfo():

	func_linecode = []

	filename = ""

	for filez in filesdata_list:
		filename = filez["file_name"]

		a = (filez["func_start_line"],filez["func_end_line"])		
		func_linecode.append(a)		

        if source_dir != "":
		fil = open(os.path.join(source_dir,filename), "r" )
	else:
		fil = open(filename, "r" )
	lines = []
	i=0
	code_line_len = []
	for line in fil:
		#sha256.update(line.encode())
		addline = True
		for c in func_linecode:
			s,e = c
			if int(i) >= int(s) and int(i) <= int(e):
				addline = False
		if addline==True:
		    	code_line_len.append({"line":i,"len":len(line)})
			lines.append(line)
			i+=1

	fil.close()
	#fil_sign = sha256.digest()
	fil_sign = ""

	(c_lines, c_comments, c_blanks, c_code, sign, l_comments) = _doLOC(lines)

	#(d, count, comment, blank) = _doLOC(lines)
	
	d = {}
	d["file_name"] = filename
	d["file_size"] = os.path.getsize(filename)
	d['file_loc'] = c_code
	d['file_ploc'] = c_lines
	d['file_comments_len'] = c_comments
	d['file_blank'] = c_blanks
	d['file_code'] = lines
	d['file_sha256'] = fil_sign
	d['file_comments'] = l_comments
	d["file_files_len"] = code_line_len
		
	filesmeta_list.append(d)

#
#
#
def DoFuncMetrics(d):

	fm = tintometrics.Func_Metrics()
	fm.CalCulateMetrics(d)
	
	m = {}
	m["count_colons"] = fm.GetCountColons()

	return m
	 		
#
#
#
def GetFileInfo(fun):
	file_dict =  {}
	file_dict['file_name'] = gcc.get_dump_base_name() 
	file_dict['func_name'] = fun.decl.name
	file_dict['func_decl'] = DoFuncDecl(fun)
	file_dict['func_basic_blocks'] = len(fun.cfg.basic_blocks) 
	file_dict['func_cc'] = DoCC(fun)
	z = GetLOC(fun)
	file_dict['func_loc'] = z['func_loc'] 
	file_dict['func_ploc'] = z['func_ploc'] 
	file_dict['func_comments_len'] = z['func_comments_len'] 
	file_dict['func_blank'] = z['func_blank']
	file_dict['func_code'] = z['func_code']
	file_dict['func_comments'] = z['func_comments']
	file_dict["func_start_line"] = z["func_start_line"]
	file_dict["func_end_line"] = z["func_end_line"]
	file_dict["func_sha256"] = z["func_sha256"]	
	if data_dict != {}:
		#for d in data_dict['api_config']:
		#	if d[0] == "do_api_dis" and d[1] == "yes":
		if data_dict["do_api"] == "yes": 
			file_dict['func_api_res'] = DoAPI(fun)
	if data_dict.has_key('show_gimple_graph') and data_dict['show_gimple_graph'] == tintolib.YES:
		n = data_dict['imgs_dir'] + "/"+ file_dict['file_name'].replace("/","_") + "_" + file_dict['func_name'] + "_gimple"
		DoGimpleGraph(fun, n)
		file_dict['gimple_graph_file'] = file_dict['file_name'].replace("/","_") + "_" + file_dict['func_name'] + "_gimple.png"			
	if data_dict.has_key('show_basicblocks_complexity') and data_dict['show_basicblocks_complexity'] == tintolib.YES:
		n = data_dict['imgs_dir'] + "/"+ file_dict['file_name'].replace("/","_") + "_" + file_dict['func_name'] + "_bbcomplexity"
		DoBBComplexityGraph(fun, n)
		file_dict['basicblocks_complexity_file'] = file_dict['file_name'].replace("/","_") + "_" + file_dict['func_name'] + "_bbcomplexity.png"	
	file_dict['func_inline_asm'] = DectectInlineASM(fun)
	file_dict['func_count_gimples'] = CountGimples(fun)		

	file_dict["func_metrics"] = DoFuncMetrics(z["func_code"])

	global filesdata_list
	filesdata_list.append(file_dict)			

#
#
#
def GetFileBB(fun):
	file_bb_dict =  {}
	file_bb_dict['file_name'] = gcc.get_dump_base_name()
        file_bb_dict['func_name'] = fun.decl.name
        file_bb_dict['func_decl'] = DoFuncDecl(fun)
        file_bb_dict['func_basic_blocks'] = len(fun.cfg.basic_blocks)

	l = len(fun.cfg.basic_blocks)
	g = []
        for i in range(0,l):
		gbb =   {}
		bb = []
		
		if fun.cfg.basic_blocks[i] == fun.cfg.entry:
			gbb["bb_data"] = "%r" % fun.cfg.entry
			gbb["desc"] = "entry"
		elif fun.cfg.basic_blocks[i] == fun.cfg.exit:
			gbb["bb_data"] = "%r" % fun.cfg.exit
			gbb["desc"] = "exit"
		else:
	        	bx = fun.cfg.basic_blocks[i]
        	        for stmt in bx.gimple:
				gbbb = {}
				try:
					gbbb["str(stmt)"] = str(stmt)
					gbbb["repr(stmt)"] = repr(stmt)
					#gbbb["loc"] = "%s" % stmt.loc
					gbbb["loc"] = ""
					try:
						gbbb["code"] = "%s" % get_src_for_loc(stmt.loc)
					except:		
						gbbb["code"] = ""
					if hasattr(stmt, 'lhs'):
						gbbb["lhs"] = "%r" % stmt.lhs
	                        	if hasattr(stmt, 'exprtype'):
						gbbb["exprtype"] = "%r" % stmt.exprtype
                       			if hasattr(stmt, 'exprcode'):
						gbbb["exprcode"] = "%r" % stmt.exprcode
                        		if hasattr(stmt, 'retval'):
						gbbb["retval"] = "%r" % stmt.retval
                        		if hasattr(stmt, 'rhs'):
						gbbb["rhs"] = "%r" % stmt.rhs
				except: pass
				bb.append(gbbb)	
			gbb["bb_data"] = bb
			gbb["desc"] = "bb"
		n = "bb_%i" % i
		gbb[n] = i
		g.append(gbb)						

        file_bb_dict['func_gimples'] = g

	global filesdata_bb_list
	filesdata_bb_list.append(file_bb_dict)			

#
#
#
def BeginOnPassExec(p,fun):

	#print(p)
	#print data_dict


	nfunc = ""

	# Call after cfg
	if p.name == "*warn_function_return":

		nfunc = fun.decl.name

		#print gcc.get_dump_base_name() 

		# CFG
		GetFileInfo(fun)
		GetFileBB(fun)

	if p.name == "*free_lang_data":

		# Do file callgraph			
		if data_dict.has_key('show_file_callgraph') and data_dict['show_file_callgraph'] == tintolib.YES:
			nfile = gcc.get_dump_base_name()	
			filez = tintolib.GetFinalOutputImgsDir() + "/" + nfile.replace("/","_") + "_callgraph"
			if not tintolib.DoFileExists(filez):
				dot = callgraph_to_dot()
				#internal_invoke_dot(dot,filez)
				tintolib.tinan_invoke_dot(dot,filez)
				global filesdata_list
				t = []
				for f in filesdata_list:
					if f['file_name'] == nfile:
						f['file_callgraph'] = nfile.replace("/","_") + "_callgraph.png"
					t.append(f)
				filesdata_list = t

#
#
#
def SaveFileData():
	#print filesdata_list
	#tintolib.WriteFileData(tintolib.GetOutputDir()+"/"+tintolib.temp_file,filesdata_list)
	tintolib.WriteFileData(tintolib.GetFinalOutputDir()+"/"+tintolib.temp_file,filesdata_list)
	tintolib.WriteFileData(tintolib.GetFinalOutputDir()+"/"+tintolib.temp_bb_file,filesdata_bb_list)
	tintolib.WriteFileData(tintolib.GetFinalOutputDir()+"/"+tintolib.temp_meta_file,filesmeta_list)

#
#
#
def finish_analysis(*args, **kwargs):
	#print "FINISH FILE"
	#print gcc.get_dump_base_name()

	try: 
		GetMetaInfo()
	except:
		pass

	SaveFileData()	

########################################################################
# Main class - DoTitan
########################################################################

# Load config file just once
if tintolib.load_config==tintolib.NO:

	do_config = tintolib.Read_Config_File("/tintorera/tinto.json")

	if do_config:

		tintolib.load_config=tintolib.YES

		#if do_config.has_key("analysis") and do_config["analysis"].has_key("do_api_dis") \
		#and do_config["analysis"]["do_api_dis"] == "yes":
		if do_config["analysis"]["do_api_dis"] == "yes":
			#data_dict['api_config'] = apidis = do_config.items("api_discovery")
			data_dict['api_data'] = tintolib.LoadAPIData(do_config["default"]["data_dir"])			
			data_dict["api"]=do_config["analysis"]["api"]
			data_dict["do_api"]="yes"
	
		#if do_config.has_option("api_discovery","do_api_dis") and do_config.get("api_discovery","do_api_dis") == "yes":
		#	data_dict['api_config'] = apidis = do_config.items("api_discovery")
		#	data_dict['api_data'] = tintolib.LoadAPIData(do_config.get("section_default","data_dir"))

		#data_dict['imgs_dir'] = do_config.get("section_default","output_dir") + "/" + tintolib.output_dir + "/" + tintolib.imgs_output_dir
		data_dict['imgs_dir'] = do_config["default"]["output_dir"] + "/" + tintolib.output_dir + "/" + tintolib.imgs_output_dir

		#source_dir = do_config.get("section_default","source_dir")
		source_dir = do_config["default"]["source_dir"]

		#if do_config.get("section_default","show_basicblocks_complexity") == "yes":
		if do_config["default"]["show_basicblocks_complexity"] == "yes":
			data_dict['show_basicblocks_complexity'] = tintolib.YES 

		#if do_config.get("section_default","show_gimple_graph") == "yes":
		if do_config["default"]["show_gimple_graph"] == "yes":
			data_dict['show_gimple_graph'] = tintolib.YES 

		#if do_config.get("section_default","show_file_callgraph") == "yes":
		if do_config["default"]["show_file_callgraph"] == "yes":
			data_dict['show_file_callgraph'] = tintolib.YES 

		#tintolib.Create_Output_Dir(do_config.get("section_default","output_dir"))			
		tintolib.Create_Output_Dir(do_config["default"]["output_dir"])

gcc.register_callback(gcc.PLUGIN_PASS_EXECUTION, BeginOnPassExec)

gcc.register_callback(gcc.PLUGIN_FINISH, finish_analysis)

# VULNEX EOF
