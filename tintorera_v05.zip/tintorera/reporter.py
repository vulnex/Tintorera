# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS
#
# Tintorera Report
#
# name: reporter.py
# init date: 01/05/14
# last date: 07/22/17
# author: Simon Roses Femerling
# desc: Create report files after analyzer.py has run
#
# www.vulnex.com

import getopt
import sys
#import ConfigParser

import numpy as np
import matplotlib.pyplot as plt

from tintorera_lib import tintolib

import jinja2

########################################################################
# Global Variable
########################################################################

data_dict =  {}

temp_file_data = None

do_code = False
do_comments = False

do_comments_cloud = False
comments_cloud_list = []
comments_cloud_text = ""

do_loc_by_hour = 100

all_files = []
all_files_func = []

templateLoader = jinja2.FileSystemLoader( searchpath="./templates" )
templateEnv = jinja2.Environment( loader=templateLoader )

template_index = "index.jinja"
template_summary = "summary.jinja"
template_files_summary = "files_summary.jinja"
template_files_info = "files_info.jinja"
template_files_func = "files_func.jinja"

########################################################################
# Funcrions
########################################################################

#
#
#
def HTML_createallfilesfunctions(dpath):

	template_info = templateEnv.get_template( template_files_info )
	template_func = templateEnv.get_template( template_files_func )

	ilist_func = []

	for d in temp_file_data:
		tmp_file = d['file_name'].replace("/","_")
		if not d['file_name'] in all_files:
			idict_data = {}
			idict_data["file"] = "%s" % d['file_name']
			idict_data["href"] = "../files.html#%s" % d['file_name']
			idict_data["total_funcs"] = data_dict['file_fnc'][d['file_name']]
			idict_data["total_bb" ] = data_dict['file_bb'][d['file_name']]
			if data_dict['file_apic'].has_key(d['file_name']):
				idict_data["total_api"] = data_dict['file_apic'][d['file_name']]
        		else:
				idict_data["total_api"] = "0"
			idict_data["total_loc"] = data_dict['file_loc'][d['file_name']]
			idict_data["total_physical_loc"] = data_dict['file_ploc'][d['file_name']]
			#print len(data_dict['file_comment'][d['file_name']])
			#print data_dict['file_comment'][d['file_name']]
			idict_data["total_comments"] = len(data_dict['file_comment'][d['file_name']])			
			idict_data["total_blanks"] = data_dict['file_blank'][d['file_name']]
			if d.has_key('file_callgraph') and d['file_callgraph'] != "":
				idict_data["do_callgraph"] = True
				idict_data["file_callgraph_alt"] = d['file_callgraph']
				idict_data["file_callgraph_src"] = "../imgs/"+d['file_callgraph']

			"""
			global do_code
			if do_code == True:
				idict_data["do_code"] = True				
				idict_data["file_code"] = "".join(d["file_code"])
				idict_data["file_code_line"] = 0
			"""

			outputText = template_info.render( idict_data )
			filez = dpath + "/" +tintolib.files_output_dir + "/" + tmp_file + ".html"
			tintolib.Write_File(filez,outputText,mode="w")
			all_files.append(tmp_file)
			
		if not d['file_name'] in all_files or not d['func_name'] in all_files_func: 
			comments_cloud_text = ""
			idict_data = {}
			idict_data["file_func"] = "%s -> %s" % (d['file_name'], d['func_name'])
			idict_data["href"] = "../files.html#%s" % d['func_name']
			idict_data["func_name"] = d['func_decl']['func_name']			
			idict_data["func_args_len"] = len(d['func_decl']['func_args'])
			idict_data["func_args"] = d['func_decl']['func_args']
			idict_data["func_return_type"] = d['func_decl']['func_return']
			idict_data["func_loc"] = str(d['func_loc'])
			idict_data["func_ploc"] = str(d['func_ploc'])
			idict_data["func_start_line"] = str(d['func_start_line'])
			idict_data["func_end_line"] = str(d['func_end_line'])
			idict_data["comments"] =str(d['func_comments_len'])
			idict_data["blank_lines"] = str(d['func_blank'])
			idict_data["bb"] = d['func_basic_blocks']
			idict_data["cc" ] = d['func_cc']
			idict_data["cc_color" ] = Calculate_CC_color(d['func_cc'])
			idict_data["func_metrics_count_colons" ] = d['func_metrics']["count_colons"]			
			if list(d['func_api_res']) != []: 
        			idict_data["func_do_api"] = True
				apil = []
				for c in d['func_api_res']:
					apid = {}
					apid["color"] = c["color"]
					apid["cat"] = c["cat"]
					apid["api"] = c["api"]
					apid["loc"] = c["loc"]
					apil.append(apid)
				idict_data["apis"] = apil
	
			if d.has_key("func_inline_asm") and d['func_inline_asm'] != "":
				idict_data["do_inline_asm"] = True			
				idict_data["inline_asm"] = d['func_inline_asm']

			if d.has_key("basicblocks_complexity_file"):
				idict_data["do_bbc"] = True				
				idict_data["img_bbc_alt"] = d['basicblocks_complexity_file']
				idict_data["img_bbc_src"] = "../imgs/"+d['basicblocks_complexity_file']

			if d.has_key("gimple_graph_file"):
				idict_data["do_gg"] = True
				idict_data["img_gg_alt"] = d['gimple_graph_file']
				idict_data["img_gg_src"] = "../imgs/"+d['gimple_graph_file']

			global do_code
			if do_code == True:
				idict_data["do_code"] = True				
				idict_data["func_code"] = "".join(d["func_code"])
				idict_data["func_code_line"] = d["func_start_line"]

			global do_comments
			if do_comments == True and d["func_comments_len"]>0:
				idict_data["do_comments"] = True				
				l = []
				for c in d["func_comments"]:
					l.append(c["comment"]+"\n")
				idict_data["func_comments"] = "".join(l)

			global do_comments_cloud
			if do_comments_cloud == True and d["func_comments_len"]>0:
				for c in d["func_comments"]:
					buf = "".join(c["comment"])
					global comments_cloud_list
					for c in comments_cloud_list:
                				#if c[0] == "comments_cloud_banned_words":
						#	for b in c[1]:
								#buf = tintolib.ReplaceStrings(buf,b,"")
						buf = tintolib.ReplaceStrings(buf,c,"")
					#global comments_cloud_text
					comments_cloud_text += buf
					#for b in comments_cloud_banned_words:
					
				filpng = tmp_file + "__" + d['func_name'] + ".png"
				idict_data["do_comments_cloud"] = True
				idict_data["comments_cloud_src"] = "../imgs/" + tmp_file + "__" + d['func_name'] + ".png"			
				idict_data["comments_cloud_alt"] = tmp_file + "__" + d['func_name'] + ".png"
				CreateWordCloud(dpath,filpng,comments_cloud_text)

			outputText = template_func.render( idict_data )
			filez = dpath + "/" +tintolib.files_output_dir + "/" + tmp_file + "__" + d['func_name'] + ".html"
			tintolib.Write_File(filez,outputText,mode="w")
			all_files_func.append(d['func_name'])

#
#
#
def HTML_createindex(dpath):

	template = templateEnv.get_template( template_index )

	templateVars = { "project" : "Test Project",
                 	"version" : tintolib.tinto_ver }

	outputText = template.render( templateVars )

	filez = dpath + "/index.html" 		
	tintolib.Write_File(filez,outputText,mode="w")

#
#
#
def HTML_summary(dpath):

	template = templateEnv.get_template( template_summary )

	templateVars = { "project" : "Test Project",
			"total_files" : data_dict['total_files'],
			"total_functions" : data_dict['total_functions'],
			"total_bb" : data_dict['total_bb'],
			"total_loc" : data_dict['total_loc'],
			"total_physical_loc" : data_dict['total_ploc'],
			"total_comments" : data_dict['total_comments'],
			"total_blanks" : data_dict['total_blank'],
			"loc_by_hour" : data_dict['loc_by_hour']
			}

	outputText = template.render( templateVars )

	filez = dpath + "/summary.html" 		
	tintolib.Write_File(filez,outputText,mode="w")

#
#
#
def HTML_createfiles(dpath):

	template = templateEnv.get_template( template_files_summary )

	ilist = []

	for fl in temp_file_data:
		idict_data = {}
		ph = tintolib.files_output_dir + "/" + fl['file_name'].replace("/","_") + ".html"	
		idict_data["file"] = fl["file_name"]
		idict_data["id_file"] = fl["file_name"]
		idict_data["href_file"] = ph
              	ph1 = tintolib.files_output_dir + "/" + fl['file_name'].replace("/","_") + "__" + fl['func_name'] + ".html"
		idict_data["func"] = fl["func_name"]
		idict_data["id_func"] = fl["func_name"]
		idict_data["href_func"] = ph1
		idict_data["bb"] = fl['func_basic_blocks']
		idict_data["cc"] = fl['func_cc']
		idict_data["cc_color"] = Calculate_CC_color(fl['func_cc'])
		if list(fl['func_api_res']) != []:
			idict_data["api"] = "YES" 
		else:
			idict_data["api"] = "&nbsp;"
		if fl['func_inline_asm'] != "":
			idict_data["func_inline_asm"] = "YES" 
		else:
			idict_data["func_inline_asm"] = "&nbsp;"
		ilist.append(idict_data)		

	outputText = template.render( items=ilist )

	filez = dpath + "/files.html" 		
	tintolib.Write_File(filez,outputText,mode="w")
	
#
#
#
def Create_FunctionPIE(dpath):

	labels = []
	sizes = []
	colors = []

	#print data_dict['api_count']

	#for c in data_dict['api_count']:
	#	print c

	for k,v in data_dict['api_count'].iteritems():
		if not k in labels:
			labels.append(k)
			sizes.append(v)
			colors.append(data_dict['api_color'][k])

	plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True)
	plt.axis('equal')
	plt.savefig(dpath+"/"+tintolib.imgs_output_dir+"/"+"functions_cat_pie.png")

#
#
#
def Create_FunctionBar(dpath):

	labels = ['gimpleasm','gimpleassign','gimplecall','gimplecond','gimplelabel','gimplenop','gimplephi','gimplereturn','gimpleswitch']

	counts = [0,0,0,0,0,0,0,0,0]
	co =  {}

	N = len(data_dict['count_gimples'][1].keys())
	for d in data_dict['count_gimples']:
		for k,v in d.iteritems():
			if not co.has_key(k):
				co[k] = v
			else:
				co[k] = co[k] + v

	for k,v in co.iteritems():
		c = str(k).lower()
		w = labels.index(str(c))
		counts[w] = v

	ind = np.arange(N)
	width = 0.5

	#print counts
	fig = plt.figure()
	rects = plt.bar(ind, counts, color='b')

	plt.ylabel('Gimples Count')
	plt.title('Total Gimples')
	plt.xticks(ind + width / 2,labels)
	#plt.yticks(np.arange(0,60000,10))
	
	fig.autofmt_xdate()
	
	for rect in rects:
		hei = rect.get_height()
		plt.text(rect.get_x()+rect.get_width()/2.,1.05*hei,'%d'%int(hei),ha='center',va='bottom')

	plt.savefig(dpath+"/"+tintolib.imgs_output_dir+"/"+"functions_gimples_bar.png")
	
#
#
#
def Calculate_CC_color(num):	
	if int(num) >= 1 and int(num) <= int(data_dict["cc_low_risk_value"]):
		 return data_dict["cc_low_risk_color"]
	elif int(num) >= int(data_dict["cc_low_risk_value"]+1) and int(num) <= int(data_dict["cc_mid_risk_value"]):
		 return data_dict["cc_mid_risk_color"]
	elif int(num) >= int(data_dict["cc_mid_risk_value"]+1) and int(num) <= int(data_dict["cc_high_risk_value"]):
		 return data_dict["cc_high_risk_color"]
	elif int(num) >= int(data_dict["cc_very_high_risk_value"]):
		 return data_dict["cc_very_high_risk_color"]
	else:
		return '#888888' #

#
#
#
def Create_CC_dict(do_config):
	#data_dict["cc_low_risk_value"] = do_config.getint("cyclomatic","low_risk_value")
	#data_dict["cc_low_risk_color"] = do_config.get("cyclomatic","low_risk_color")
	#data_dict["cc_mid_risk_value"] = do_config.getint("cyclomatic","mid_risk_value")
	#data_dict["cc_mid_risk_color"] = do_config.get("cyclomatic","mid_risk_color")
	#data_dict["cc_high_risk_value"] = do_config.getint("cyclomatic","high_risk_value")
	#data_dict["cc_high_risk_color"] = do_config.get("cyclomatic","high_risk_color")
	#data_dict["cc_very_high_risk_value"] = do_config.getint("cyclomatic","very_high_risk_value")
	#data_dict["cc_very_high_risk_color"] = do_config.get("cyclomatic","very_high_risk_color")

	data_dict["cc_low_risk_value"] = do_config["report"]["low_risk_value"]
	data_dict["cc_low_risk_color"] = do_config["report"]["low_risk_color"]
	data_dict["cc_mid_risk_value"] = do_config["report"]["mid_risk_value"]
	data_dict["cc_mid_risk_color"] = do_config["report"]["mid_risk_color"]
	data_dict["cc_high_risk_value"] = do_config["report"]["high_risk_value"]
	data_dict["cc_high_risk_color"] = do_config["report"]["high_risk_color"]
	data_dict["cc_very_high_risk_value"] = do_config["report"]["very_high_risk_value"]
	data_dict["cc_very_high_risk_color"] = do_config["report"]["very_high_risk_color"]

#
#
#
def Do_Calculations():

	# Get number of total files, functions
	f = []
	fn = []
	cat_dict = {}
	cat_color_dict = {}
	file_bb_dict = {}
	file_loc_dict = {}
	file_ploc_dict = {}
	file_comment_dict = {}
	file_blank_dict = {}
	total_bb = 0
	total_loc = 0
	total_ploc = 0
	total_comment = 0
	total_blank = 0
	gimple_list = []
	file_fnc_dict = {}
	file_apic_dict = {}
	for c in temp_file_data:
		if not c['file_name'] in f:
			f.append(c['file_name'])
		if not c['func_name'] in f:
			fn.append(c['func_name'])
		if c['func_api_res'] != []:
			for i in c['func_api_res']:
				if not cat_dict.has_key(i['cat']):
					cat_dict[i['cat']] = 1 
					cat_color_dict[i['cat']] = i['color']
				else:
					cat_dict[i['cat']] += 1 
				if not file_apic_dict.has_key(c['file_name']):
					file_apic_dict[c['file_name']] = 1
				else:
					file_apic_dict[c['file_name']] = file_apic_dict[c['file_name']] + 1

		total_bb = total_bb + c['func_basic_blocks']		
		total_loc = total_loc + c['func_loc']		
		total_ploc = total_ploc + c['func_ploc']		
		total_comment = total_comment + c['func_comments_len']		
		total_blank = total_blank + c['func_blank']		
		gimple_list.append(c['func_count_gimples'])
		if not file_bb_dict.has_key(c['file_name']):
			file_fnc_dict[c['file_name']] = 1
			file_bb_dict[c['file_name']] = c['func_basic_blocks']
			file_loc_dict[c['file_name']] = c['func_loc']
			file_ploc_dict[c['file_name']] = c['func_ploc']
			file_comment_dict[c['file_name']] = c['func_comments']
			file_blank_dict[c['file_name']] = c['func_blank']
		else:
			file_fnc_dict[c['file_name']] = file_fnc_dict[c['file_name']] + 1
			file_bb_dict[c['file_name']] = file_bb_dict[c['file_name']] + c['func_basic_blocks']	
			file_loc_dict[c['file_name']] = file_loc_dict[c['file_name']] + c['func_loc']	
			file_ploc_dict[c['file_name']] = file_ploc_dict[c['file_name']] + c['func_ploc']	
			file_comment_dict[c['file_name']] = file_comment_dict[c['file_name']] + c['func_comments']	
			file_blank_dict[c['file_name']] = file_blank_dict[c['file_name']] + c['func_blank']	
			
	data_dict['total_files'] = len(f)
	data_dict['total_functions'] = len(fn)
	data_dict['api_count'] = cat_dict
	data_dict['api_color'] = cat_color_dict
	data_dict['total_bb'] = total_bb
	data_dict['total_loc'] = total_loc
	data_dict['total_ploc'] = total_ploc
	data_dict['total_comments'] = total_comment
	data_dict['total_blank'] = total_blank
	data_dict['count_gimples'] = gimple_list
	data_dict['file_bb'] = file_bb_dict
	data_dict['file_loc'] = file_loc_dict
	data_dict['file_ploc'] = file_ploc_dict
	data_dict['file_comment'] = file_comment_dict
	data_dict['file_blank'] = file_blank_dict
	data_dict['file_fnc'] = file_fnc_dict
	data_dict['file_apic'] = file_apic_dict
	global do_loc_by_hour
	data_dict['loc_by_hour'] = total_loc / do_loc_by_hour 
	
#
#
#
def LoadDataFiles(dpath):
	global temp_file_data
	temp_file_data = tintolib.ParseFileData(dpath+"/"+tintolib.temp_file)

#
#
#
def CreateWordCloud(dpath,fil="",itext=""):
	
	#file = dpath + "/" + tintolib.imgs_output_dir + "/" + "cloud_image.png"
	file = dpath + "/" + tintolib.imgs_output_dir + "/" + fil

	tintolib.CreateWordCloud(file,itext) 

	return file	
#
#
#
def Usage():
	print "Tintorera Reporting Tool"
	print "Usage: report_tinan.py -c tinan.cfg"
	print ""
	print "-h: This help"
	print "-v: Be verbose"	
	print "-c: config file"
	sys.exit(2)

#
#
#
def domain(c="",beverbose=tintolib.NO):
	#do_config = ConfigParser.ConfigParser()
	#do_config.read(c)
	do_config = tintolib.Read_Config_File(c)

	#output_dir = do_config.get("section_default","output_dir")
	output_dir = do_config["default"]["output_dir"]

	#show_code = do_config.get("section_default","show_code")
	show_code = do_config["report"]["show_code"]
	if show_code == str("yes"):
		global do_code
		do_code = True

	#show_comments = do_config.get("section_default","show_comments")
	show_comments = do_config["report"]["show_comments"]
	if show_comments == str("yes"):
		global do_comments
		do_comments = True

	#show_comments_cloud = do_config.get("section_default","show_comments_cloud")
	show_comments_cloud = do_config["report"]["show_comments_cloud"]
	if show_comments_cloud == str("yes"):
		global do_comments_cloud
		do_comments_cloud = True
		global comments_cloud_list
		#comments_cloud_list = do_config.items("comments_cloud")
		comments_cloud_list = do_config["report"]["comments_cloud_banned_words"]

	#lochour = do_config.getint("section_default","loc_by_hour")
	lochour = do_config["report"]["loc_by_hour"]
	try:
		global do_loc_by_hour
		do_loc_by_hour = lochour
	except:
		#global do_loc_by_hour
		#do_loc_by_hour = 100
		pass
	
	#
	Create_CC_dict(do_config)

	LoadDataFiles(output_dir+"/"+tintolib.output_dir)

        Do_Calculations()

	#Begin creating report files

	#CreateWordCloud(output_dir+"/"+tintolib.output_dir)

	HTML_createallfilesfunctions(output_dir+"/"+tintolib.output_dir)
	HTML_createindex(output_dir+"/"+tintolib.output_dir)
	HTML_summary(output_dir+"/"+tintolib.output_dir)
	HTML_createfiles(output_dir+"/"+tintolib.output_dir)

	Create_FunctionPIE(output_dir+"/"+tintolib.output_dir)
	Create_FunctionBar(output_dir+"/"+tintolib.output_dir)

	#dele = do_config.get("section_default","delete_temp_file")
	dele = do_config["default"]["delete_temp_file"]
	if dele == str("yes"):
		tintolib.DeleteFile(output_dir+"/"+tintolib.output_dir+"/"+tintolib.temp_file)		

########################################################################
# Main
########################################################################
if __name__ == "__main__":

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hvc:")
	except:
		Usage()

	c=""
	beverbose=tintolib.NO

	for o,a in opts:
		if o == "-h":
			Usage()
		if o == "-v":
			beverbose=tintolib.YES
		if o == "-c":
			c = a
		else:
			Usage()

	if c == "": Usage()

	domain(c,beverbose)

# VULNEX EOF
