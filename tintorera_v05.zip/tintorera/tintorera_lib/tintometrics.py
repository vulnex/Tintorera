# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS 
# 
# Tintorera Library
# 
# name: tintometrics.py
# date: 11/05/14
# author: Simon Roses Femerling
# desc: Tintorera Metrics Library
#
# www.vulnex.com

import os
import sys

########################################################################
# Global Variables
########################################################################

########################################################################
# Functions
########################################################################

class Func_Metrics:

	def __init__(self):
		"""
		"""
		self.SetInit()

	def SetInit(self):
		"""
		"""

		self.count_colons = 0

	def GetCountColons(self):
		"""
		"""
		return self.count_colons

	def CalCulateMetrics(self,data=""):
		"""
		"""	
		
		if data == "": return

		self.count_colons = self.CountColons("".join(data))

	def CountColons(self,d=""):

		if d == "": return

		return d.count(";",0,len(d))

# VULNEX EOF
