# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS 
# 
# Tintorera Library
# 
# name: tintolib.py
# date: 09/10/16
# author: Simon Roses Femerling
# desc: Tintorera library file
#
# www.vulnex.com

import os
import sys

#import csv
import json

do_cloud=True
try:
	from pytagcloud import create_tag_image, make_tags
	from pytagcloud.lang.counter import get_tag_counts
except:
	do_cloud=False

########################################################################
# Global Variables
########################################################################

YES=0
NO=1

load_config=NO
do_config=None

temp_file="tintorera_temp_file.json"
temp_bb_file="tintorera_bb_file.json"
temp_meta_file="tintorera_meta_file.json"
output_dir='tinan_output'
imgs_output_dir='imgs'
files_output_dir='files'

final_output_dir=''
final_output_files=''
final_output_imgs=''

filesdata_list = []

scan_files = []

tinto_api = "tinto_api.json"

tinto_ver = "0.5"

langs = {
        "C": {
            "bcomm":        {"/*": "*/"},
            "comment":      ["//"],
            "endcode":      [],
            "ext":          [".c"],
            },
        "C++": {
            "bcomm":        {"/*": "*/"},
            "comment":      ["//"],
            "endcode":      [],
            "ext":          [".cpp"],
            }
	}

########################################################################
# Helpers Functions
########################################################################

#
#
#
def Read_Config_File(filename=""):
	res={}
	with open(filename,"r") as json_data:
    		res = json.load(json_data)
  	return res

#
#
#
def Write_File(filename="",data="",mode="a"):
	try:
		f = open(filename,mode)
		try:
			f.write(data)
			f.flush()
		finally:
			f.close()
	except IOError as e:
		print "IO Error({0}): {1}".format(e.errno, e.strerror)

#
#
#
def DeleteFile(dpath):
	os.remove(dpath)

def DoFileExists(fpath):
	return os.path.exists(fpath)

#
# create output dir
#
def Create_Output_Dir(d):
	global final_output_dir
	global final_output_imgs
	global final_output_files
	
	final_output_dir = d + "/" + output_dir
	final_output_imgs = final_output_dir+"/"+imgs_output_dir
	final_output_files = final_output_dir+"/"+files_output_dir 

	if not DoFileExists(final_output_dir): 
		os.makedirs(final_output_dir)
	if not DoFileExists(final_output_dir+"/"+imgs_output_dir): 
		os.makedirs(final_output_imgs)
	if not DoFileExists(final_output_dir+"/"+files_output_dir): 
		os.makedirs(final_output_files)

#
#
#
def GetFinalOutputDir():
	return final_output_dir

#
#
#
def GetFinalOutputFilesDir():
	return final_output_files

#
#
#
def GetFinalOutputImgsDir():
	return final_output_imgs

#
#
#
def WriteFileData(filepath,l,mode="wb"):
	if os.path.exists(filepath):
		#print "OPEn FILE :" + filepath
		#print "DATA :" 
		#print l
		c = ParseFileData(filepath)
		for c1 in c:
			l.append(c1)
 		with open(filepath,mode) as f:
			#json.dump(l,f,indent=4,ensure_ascii=False).encode('utf8')	
			json.dump(l,f,indent=4)	
	else:
		#print "NEW FILE :" + filepath
		#print "DATA :"
		#print l
		
 		with open(filepath,mode) as f:
			#json.dump(l,f,indent=4,ensure_ascii=False).encode('utf8')	
			json.dump(l,f,indent=4)	
		
		#f = open(filepath,mode)
		#json.dump(l,f,indent=4)
		#f.flush()
		#f.close()

#
#
#
def ParseFileData(filepath,mode='rb'):
 	with open(filepath,'rb') as f:
		jdata = f.read().strip('\n')
		dat = json.loads(jdata)
	return dat

	"""	
	dat = []

	with open(filepath) as f:

		for line in f:
			print line
			dat.append(json.loads(line))

	print dat
	"""

	#with open(filepath,"r") as f:
	#	t = f.read()	
	#	dat = json.loads(t)
	#print dat

	
	"""	
	with open(filepath,"r") as f:
		d = f.read()

	for c in d:
		print c
		load_data = json.loads(c)
		print load_data
	

	dat = []
	f = open(filepath,"r")
	try:
		reader = csv.reader(f)
		for row in reader:
			dat.append(row)
	finally:
		f.close()
	return dat
	"""
#
#
#
def LoadAPIData(dpath,file=tinto_api):
	return ParseFileData(dpath+"/"+file)

#
#
#
def SetOutputDir(d):
	global final_output_dir
	final_output_dir = d

#
#
#
def GetOutputDir():
	return final_output_dir

#
#
#
def ReplaceStrings(s1="",s2="",s3=""):
	s1 = s1.replace(s2,s3)
	return s1

#
#
#
def CreateWordCloud(filename='',data=''):

	global do_cloud
	if filename == "" or data == "" or do_cloud==False: return

	tags = make_tags(get_tag_counts(data), maxsize=120)

	create_tag_image(tags, filename, size=(900, 600), fontname='Lobster')

#
#
# http://thelivingpearl.com/2013/10/24/compute-the-average-min-max-and-mode-of-a-list-in-python/
def Calculate_Average(li=[]):
	sum = 0
	for elm in li:
		sum += elm 
	return str(sum/(len(li)*1.0))

#
#
# http://thelivingpearl.com/2013/10/24/compute-the-average-min-max-and-mode-of-a-list-in-python/
def Calculate_Minimum(li=[]):
 	min = li[0]
	for elm in li[1:]:
		if elm < min:            
			min = elm               
	return str(min)    

#
#
# http://thelivingpearl.com/2013/10/24/compute-the-average-min-max-and-mode-of-a-list-in-python/
def Calculate_Maximum(li=[]):
	max = li[0]       
	for elm in li[1:]:        
		if elm > max:
			max = elm
	return str(max)

#
#
#
def SaveFileJson(filename,data):
	with open(filename, 'w') as fp:
    		json.dump(data, fp)

########################################################################
# Graph & Visuals Functions
########################################################################

class Tinan_CfgPrettyPrinter():
    # Generate graphviz source for this gcc.Cfg instance, as a string
    def __init__(self, cfg, name=None):
        self.cfg = cfg
        if name:
            self.name = name

    def block_id(self, b):
        if b is self.cfg.entry:
            return 'entry'
        if b is self.cfg.exit:
            return 'exit'
        return 'bb_%i' % id(b)

    def block_to_dot_label(self, bb):
        # FIXME: font setting appears to work on my machine, but I invented
        # the attribute value; it may be exercising a failure path
        result = '<font face="monospace"><table cellborder="0" border="0" cellspacing="0">\n'
        if bb.index == 0:
            result += '<tr> <td>Entry</td> <td></td> </tr>\n'
        elif bb.index == 1:
            result += '<tr> <td>Exit</td> <td></td> </tr>\n'
        else:
            result += '<tr> <td>bb_%i</td> <td></td> </tr>\n' % bb.index
        """
        curloc = None
        if isinstance(bb.gimple, list) and bb.gimple != []:
            for stmtidx, stmt in enumerate(bb.gimple):
                if curloc != stmt.loc:
                    curloc = stmt.loc
                    if curloc is not None:
                        code = get_src_for_loc(stmt.loc).rstrip()
                        pseudohtml = self.code_to_html(code)
                        # print('pseudohtml: %r' % pseudohtml)
                        result += ('<tr><td align="left">'
                                   + self.to_html('%4i ' % stmt.loc.line)
                                   + pseudohtml
                                   + '<br/>'
                                   + (' ' * (5 + stmt.loc.column-1)) + '^'
                                   + '</td></tr>')

                result += '<tr><td></td>' + self.stmt_to_html(stmt, stmtidx) + '</tr>\n'
        else:
            # (prevent graphviz syntax error for empty blocks):
            result += self._dot_tr(self.block_id(bb)
        """
        result += '</table></font>\n'
        return result

    def code_to_html(self, code):
        if using_pygments:
            return code_to_graphviz_html(code)
        else:
            return self.to_html(code)

    """
    def stmt_to_html(self, stmt, stmtidx):
        text = str(stmt).strip()
        text = self.code_to_html(text)
        bgcolor = None

        # Work towards visualization of CPython refcounting rules.
        # For now, paint assignments to (PyObject*) vars and to ob_refcnt
        # fields, to highlight the areas needing tracking:
        # print 'stmt: %s' % stmt
        if 0: # hasattr(stmt, 'lhs'):
            # print 'stmt.lhs: %s' % stmt.lhs
            # print 'stmt.lhs: %r' % stmt.lhs
            if stmt.lhs:
                # print 'stmt.lhs.type: %s' % stmt.lhs.type

                # Color assignments to (PyObject *) in red:
                if str(stmt.lhs.type) ==
    """
    
    def edge_to_dot(self, e):
	#print e.loop_exit
	#print e.can_fallthru
        if e.true_value:
            attrliststr = '[label = true]'
        elif e.false_value:
            attrliststr = '[label = false]'
        elif e.loop_exit:
            attrliststr = '[label = loop_exit]'
        elif e.can_fallthru:
            attrliststr = '[label = fallthru]'
        else:
            attrliststr = ''
        return ('   %s -> %s %s;\n'
                % (self.block_id(e.src), self.block_id(e.dest), attrliststr))

    def extra_items(self):
        # Hook for expansion
        return ''

    def to_dot(self):
        if hasattr(self, 'name'):
            name = self.name
        else:
            name = 'G'
        result = 'digraph %s {\n' % name
        result += ' subgraph cluster_cfg {\n'
        #result += '  label="CFG";\n'
        result += '  node [shape=ellipse color=blue style=filled fontcolor=white];\n'
        for block in self.cfg.basic_blocks:

            result += ('  %s [label=<%s>];\n'
                       % (self.block_id(block), self.block_to_dot_label(block)))

            for edge in block.succs:
                result += self.edge_to_dot(edge)
            # FIXME: this will have duplicates:
            #for edge in block.preds:
            #    result += edge_to_dot(edge)
        result += ' }\n'

        # Potentially add extra material:
        result += self.extra_items()
        result += '}\n'
        return result

#
#
# RIpped and modify from gcc-python-plugin gccutils
def tinan_invoke_dot(dot, name='test'):
        from subprocess import Popen, PIPE
        fmt = 'png'
        filename = '%s.%s' % (name, fmt)
        p = Popen(['dot', '-T%s' % fmt, '-o', filename],
        stdin=PIPE)
        p.communicate(dot.encode('ascii'))

#
#
#
def tinan_cfg_to_dot(cfg, name = None):
    pp = Tinan_CfgPrettyPrinter(cfg, name)
    return pp.to_dot()

########################################################################
# Profanity Functions
########################################################################

def scan_dir(dir):
	for name in os.listdir(dir):
		path = os.path.join(dir, name)
		if os.path.isfile(path):
			global scan_files
			scan_files.append(path)
		else:
			scan_dir(path)
def load_dicts(dir):
	l=[]
	for name in os.listdir(dir):
		path = os.path.join(dir, name)
		if os.path.isfile(path):
			l.append(path)
	return l

def return_scan_files():
	global scan_files
	return scan_files

# VULNEX EOF
