# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS
#
# Tintorera Multi Report
#
# name: reporter.py
# init date: 07/22/17
# last date: 07/22/17
# author: Simon Roses Femerling
# desc: Create report files for Profanity, OSINTER, etc. 
#
# www.vulnex.com

import getopt
import sys

from tintorera_lib import tintolib

import jinja2

########################################################################
# Global Variable
########################################################################

templateLoader = jinja2.FileSystemLoader( searchpath="./templates" )
templateEnv = jinja2.Environment( loader=templateLoader )

template_profanity = "files_profanity.jinja"
template_osint = "files_osint.jinja"

########################################################################
# Funcrions
########################################################################

#
#
#
def HTML_createprofanity(dpath):

	template = templateEnv.get_template( template_profanity )

	file_data = tintolib.ParseFileData(dpath+"/"+"profanity.json")

	ilist = []
	for fl in file_data["profanity"]:
		dd={}
		dd["file"] =  fl["scanfile"]
		dd["word"] = fl["word"]
		dd["scandict"] = fl["scandict"]
		ilist.append(dd)

	outputText = template.render( items=ilist )

	filez = dpath + "/files_profanity.html" 
	tintolib.Write_File(filez,outputText,mode="w")

#
#
#
def HTML_createosint(dpath):

	template = templateEnv.get_template( template_osint )

	file_data = tintolib.ParseFileData(dpath+"/"+"osinter.json")

	ilist = []
	for fl in file_data["osint"]:
		dd={}
		dd["file"] =  fl["file"]
		dd["btc_addresses"] =  fl["btc_addresses"]
		dd["links"] =  fl["links"]
		dd["phones"] =  fl["phones"]
		dd["twitter"] =  fl["twitter"]
		dd["ipv6s"] =  fl["ipv6s"]
		dd["ips"] =  fl["ips"]
		dd["credit_cards"] =  fl["credit_cards"]
		dd["street_addresses"] =  fl["street_addresses"]
		dd["emails"] =  fl["emails"]
		ilist.append(dd)

	outputText = template.render( items=ilist )

	filez = dpath + "/files_osint.html" 
	tintolib.Write_File(filez,outputText,mode="w")

#
#
#
def Usage():
	print "Tintorera Multi Reporting Tool"
	print "Usage: multirepoter.py -c tinan.cfg -t 1"
	print ""
	print "-h: This help"
	print "-v: Be verbose"	
	print "-c: config file"
	print "-t: Type (1 - Profanity, 2 - OSINT)"
	sys.exit(2)

#
#
#
def domain(data={}):
	do_config = tintolib.Read_Config_File(data["config"])

	output_dir = do_config["default"]["output_dir"]

	if data["type"] == 1:
		HTML_createprofanity(output_dir+"/"+tintolib.output_dir)
	elif data["type"] == 2:
		HTML_createosint(output_dir+"/"+tintolib.output_dir)

########################################################################
# Main
########################################################################
if __name__ == "__main__":

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hvc:t:")
	except:
		Usage()

	data= {}	
	data["config"] = ""
	data["verbose"] = False
	data["type"] = 0

	for o,a in opts:
		if o == "-h":
			Usage()
		elif o == "-v":
			data["verbose"] = True
		elif o == "-c":
			data["config"] = a
		elif o == "-t":
			data["type"] = int(a)
		else:
			Usage()

	if data["config"] == "": Usage()

	domain(data)

# VULNEX EOF
