# TINTORERA SUITE - SECURITY SOURCE CODE ANALYSIS TOOLS
#
# Tintorera Profanity
#
# name: profaniter.py
# init date: 07/22/17
# last date: 07/22/17
# author: Simon Roses Femerling
# desc: Search for banned words (profanity) in code files
#
# www.vulnex.com

import getopt
import sys
import re

from tintorera_lib import tintolib

########################################################################
# Global Variable
########################################################################

data_dict =  {}

do_source_code_file_only = False

do_verbose = False

source_code_file_list = []

profanity_dict_path = ""

profanity_list = []

output_dir = ""

########################################################################
# Funcrions
########################################################################

#
#
#
def Usage():
	print "Tintorera Profanity"
	print "Usage: profanity.py -c tinto.json"
	print ""
	print "-h: This help"
	print "-v: Be verbose"	
	print "-f: Single file"
	print "-p: Path to folder"
	sys.exit(2)

#
#
#
def RunProfaDictsOnFile(scanfile):
	profiles = tintolib.load_dicts(profanity_dict_path)
	for p in profiles:
		try:
			fp = open(p)
		except: continue
		wordlist = fp.readlines()
		wordlist = [w.strip() for w in wordlist if w]

		sp = open(scanfile)
		text = "".join(sp.readlines())

		for wl in wordlist:
			wl = "\\b%s\\b" % wl
			m = re.search(wl, text, re.IGNORECASE)
			if m:
				try:
					if do_verbose:
						print "%s - %s - %s" % (scanfile,p,m.group())
					dd = {}
					dd["scanfile"] = scanfile
					dd["scandict"] = p
					dd["word"] = m.group() 
					global profanity_list 
					profanity_list.append(dd)
				except: pass

	if profanity_list:
		datax = {}
		datax["profanity"] = profanity_list
		global output_dir
		try:
			tintolib.SaveFileJson(output_dir + "/" + tintolib.output_dir + "/" + "profanity.json",datax)
		except:
			tintolib.SaveFileJson(output_dir + "/" + "profanity.json",datax)		
#
#
#
def RunProfanity(data):
	if data["file"] != "":
		RunProfaDictsOnFile(data["file"])
	else:
		tintolib.scan_dir(data["folder"])
		global scan_files
		scan_files = tintolib.return_scan_files()
		for f in scan_files:
			RunProfaDictsOnFile(f)

#
#
#
def doprofanity(data={}):
	if not data: Usage()

	do_config = tintolib.Read_Config_File(data["config"])

	if do_config:
		global output_dir
		output_dir = do_config["default"]["output_dir"]

		global profanity_dict_path
		profanity_dict_path = do_config["profanity"]["path_dict"]

		scf = do_config["profanity"]["do_code_files"]
		if scf == str("yes"):
			global do_source_code_file_only
			do_source_code_file_only = True

		source_code_file_list = do_config["profanity"]["code_files"]

		RunProfanity(data)
	else:
		Usage()

########################################################################
# Main
########################################################################
if __name__ == "__main__":

	try:
		opts, args = getopt.getopt(sys.argv[1:], "hvc:f:p:")
	except:
		Usage()

	data = {}
	data["config"] = ""
	data["verbose"] = tintolib.NO
	data["folder"] = ""
	data["file"] = ""

	for o,a in opts:
		if o == "-h":
			Usage()
		elif o == "-c":
			data["config"] = a
		elif o == "-f":
			data["file"] = a
		elif o == "-p":
			data["folder"] = a
		elif o == "-v":
			do_verbose = True
		else:
			Usage()

	if data["config"] == "": Usage()

	if data["folder"] == "" and data["file"] == "":
		Usage()

	if data["folder"] != "" and data["file"] != "":
		Usage()

	doprofanity(data)

# VULNEX EOF
